﻿$(document).ready(function (ev) {
    let $myModal = $("#myModal");
    //let $deletedRow;
    $myModal.on("show.bs.modal", function (ev) {  //fired when modal is about to be shown

        var button = ev.relatedTarget;
        var teamId = $(button).attr("data-id");
        var teamName = button.getAttribute('data-name');

        var $modalTitle = $('.modal-title');

        $modalTitle.text(`Delete Team ${teamName}?`);
        $myModal.attr("data-id", teamId);
        $myModal.attr("data-name", teamName);
    });

    $("#yesButton").click(function (ev) {    //fired when 'Yes' button is clicked
        addAlert($myModal.attr("data-name"))   //insert an alert in 'alertContainer'
        $(`#team${$myModal.attr("data-id")}`).closest("tr").remove();
        //$myModal.data("tobedeleted").remove();
    })

    function addAlert(teamName) {
        let alertHtml = `<div id="deleteAlert" class="alert alert-warning alert-dismissible fade show" role="alert">
            <strong>You deleted Team: ${teamName}</span>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div>`;
        $("#alertContainer").html(alertHtml);

    }

    
    $('.t1-popover').popover({
        placement: 'right',
        title: 'Team M',
        content: 'We will Mess you up!',
        trigger: 'hover',
        delay: {show: "500", hide: "100"}
    });
    
    $('.t2-popover').popover({
        placement: 'right',
        title: 'Team A',
        content: 'Apples are good for you!',
        trigger: 'hover',
        delay: { show: "500", hide: "100" }
    });

    $('.t3-popover').popover({
        placement: 'right',
        title: 'Team R',
        content: 'The Rowdy Bunch!',
        trigger: 'hover',
        delay: { show: "500", hide: "100" }
    });

    $('.t4-popover').popover({
        placement: 'right',
        title: 'Team I',
        content: 'Who name their team I? Oh, we do!',
        trigger: 'hover',
        delay: { show: "500", hide: "100" }
    });

    $('.t5-popover').popover({
        placement: 'right',
        title: 'Team O',
        content: 'It is Over for the rest of them!',
        trigger: 'hover',
        delay: { show: "500", hide: "100" }
    });
});



